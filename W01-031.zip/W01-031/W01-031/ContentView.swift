//
//  ContentView.swift
//  W01-031
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Image("balip")
            Image("alip")
                .resizable()
                .scaledToFill()
                .frame(width: 200, height: 200)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.blue, lineWidth: 2))
                .font(.title)
                .padding(.top, -750)
                .shadow(radius: 10)
            Text("Hi!, I'm, \(name)")
                .fontWeight(.bold)
                .padding(.top, -480)
                .fontDesign(.monospaced)
                .background(Color.yellow)
            Text("My age is \(age)")
                .fontWeight(.bold)
                .fontDesign(.monospaced)
                .background(Color.green)
                .padding(.top, -450)
            Text("🙈😎😍")
                .font(.system(size: 40))
                .background(Color.red)
                .padding(.top, -410)
            Text("📞")
                .font(.system(size: 100))
                .padding(.top, -360)
                .shadow(radius: 60)

//
            
        }
        .padding()
    }
    let name = "Alif Akbar"
    var age = 20
    func greet(){
        print("I am, \(name), \(age) years old")
    }
}

#Preview {
    ContentView()
}
