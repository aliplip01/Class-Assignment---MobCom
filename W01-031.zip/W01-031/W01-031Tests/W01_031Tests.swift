//
//  W01_031Tests.swift
//  W01-031Tests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_031

struct W01_031Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
