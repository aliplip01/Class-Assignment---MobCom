//
//  HomeView.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

// HomeView.swift
import SwiftUI

struct HomeView: View {
    @StateObject private var store = MovieStore()
    @State private var searchText: String = ""
    
    // for gift box
    @State private var selectedMovie: Movie? = nil
    @State private var showAlert: Bool = false
    
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return store.movies
        } else {
            return store.movies.filter { movie in
                movie.title.localizedCaseInsensitiveContains(searchText) ||
                movie.genre.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                VStack {
                    // Title
                    Text("🎬 UCFlix")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                        .padding(.top, 20)
                    
                    Text("Browse your favorite movies")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.8))
                        .padding(.bottom, 10)
                    
                    Divider()
                        .background(Color.red)
                    
                    // Search Bar
                    TextField("🔎 Search...", text: $searchText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                        .padding(.bottom, 5)
                    
                    // Movie Grid
                    MovieGridView(store: storeWithFilter)
                }
                .background(Color.black.edgesIgnoringSafeArea(.all))
                
                // Gift Box in bottom-right corner
                GiftBoxView(selectedMovie: $selectedMovie,
                            showAlert: $showAlert,
                            movies: store.movies)
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("🎁 You got a movie!"),
                    message: Text("Your random movie is: \(selectedMovie?.title ?? "Unknown")"),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
    
    private var storeWithFilter: MovieStore {
        let tempStore = MovieStore()
        tempStore.movies = filteredMovies
        return tempStore
    }
}

#Preview {
    HomeView()
        .preferredColorScheme(.dark)
}
