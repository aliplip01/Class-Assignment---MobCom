//
//  Movie.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import Foundation

struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let genre: String
    let poster: String   // use system images for now (SF Symbols)
    let synopsis: String
}

