//
//  MovieStore.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import Foundation
internal import Combine

class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(
            title: "Inception",
            genre: "Sci-Fi",
            poster: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn3.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcQovCe0H45fWwAtV31ajOdXRPTxSsMQgPIQ3lcZX_mAW0jXV3kH&psig=AOvVaw3XZPLnHcazsiYzJ9ri8D_B&ust=1759536945114000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCKDH_obghpADFQAAAAAdAAAAABAE",
            synopsis: "A skilled thief enters dreams to steal secrets."),
        Movie(
            title: "Interstellar",
            genre: "Adventure",
            poster: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn0.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcT9oW0XQlu1lo1G_49M-YwGzKR6rUg-CtflZj07HfbT8d2GwKWg&psig=AOvVaw28BBIbR7DmBl7dcgAFFME6&ust=1759537033175000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCOCQp7DghpADFQAAAAAdAAAAABAE",
            synopsis: "Astronauts travel through a wormhole in space."),
        Movie(
            title: "Avengers",
            genre: "Action",
            poster: "https://itswynnesworld.com/2012/04/29/the-avengers-a-review/",
            synopsis: "Earth’s mightiest heroes team up to save the world."),
        Movie(
            title: "Parasite",
            genre: "Drama",
            poster: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn1.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcRa9QXcKkW6fhivLE4LjAdeC7CvLFnJk5vRjkK7siVD5TkeXVfU&psig=AOvVaw0eHY4f80KXQ14lI5IH2U2b&ust=1759537073469000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCPDcwsPghpADFQAAAAAdAAAAABAE",
            synopsis: "A poor family infiltrates a wealthy household.")
    ]
}

