//
//  W4_MobCom_Muh__Nur_Alif_Akbar_0706022310031App.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import SwiftUI

@main
struct W4_MobCom_Muh__Nur_Alif_Akbar_0706022310031App: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}

#Preview {
    HomeView()
}
