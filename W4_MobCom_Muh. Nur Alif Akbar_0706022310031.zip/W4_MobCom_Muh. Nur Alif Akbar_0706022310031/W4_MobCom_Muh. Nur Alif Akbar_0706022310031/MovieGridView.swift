//
//  MovieGridView.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import SwiftUI

struct MovieGridView: View {
    @ObservedObject var store: MovieStore
    
    // grid with 2 flexible columns
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(store.movies) { movie in
                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                        MovieCard(movie: movie)
                    }
                }
            }
            .padding()
        }
    }
}

#Preview {
    NavigationStack {
        MovieGridView(store: MovieStore())
    }
}

