//
//  GiftBoxView.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import SwiftUI

struct GiftBoxView: View {
    @Binding var selectedMovie: Movie?
    @Binding var showAlert: Bool
    let movies: [Movie]
    
    @State private var jump = false
    
    var body: some View {
        VStack(spacing: 4) {
            Button {
                if let randomMovie = movies.randomElement() {
                    selectedMovie = randomMovie
                    showAlert = true
                }
            } label: {
                Image(systemName: "gift.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.red)
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: .red.opacity(0.6), radius: 5, x: 0, y: 3)
                    .offset(y: jump ? -5 : 5) // jumping effect
                    .animation(
                        Animation.easeInOut(duration: 0.6)
                            .repeatForever(autoreverses: true),
                        value: jump
                    )
            }
            
            Text("Press me")
                .font(.caption2)
                .foregroundColor(.white)
        }
        .onAppear {
            jump.toggle()
        }
    }
}

#Preview {
    ZStack {
        Color.black.ignoresSafeArea()
        GiftBoxView(selectedMovie: .constant(nil),
                    showAlert: .constant(false),
                    movies: MovieStore().movies)
    }
    .preferredColorScheme(.dark)
}

