//
//  MovieCard.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import SwiftUI

struct MovieCard: View {
    let movie: Movie
    
    var body: some View {
        VStack(spacing: 0) {
            // Poster
            if let url = URL(string: movie.poster), movie.poster.starts(with: "http") {
                AsyncImage(url: url) { image in
                    image.resizable()
                         .scaledToFill()
                } placeholder: {
                    ZStack {
                        Color.gray.opacity(0.3)
                        ProgressView()
                    }
                }
                .frame(height: 180)
                .clipped()
            } else {
                Image(movie.poster)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 180)
                    .clipped()
            }
            
            // Info section
            VStack(alignment: .leading, spacing: 4) {
                Text(movie.title)
                    .font(.headline)
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text(movie.genre)
                    .font(.subheadline)
                    .foregroundColor(.red.opacity(0.8))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.black.opacity(0.8))
        }
        .frame(width: 160, height: 240)
        .background(Color(.darkGray))
        .cornerRadius(15)
        .shadow(color: .red.opacity(0.4), radius: 8, x: 0, y: 5)
    }
}

#Preview {
    MovieCard(movie: Movie(title: "Inception",
                           genre: "Sci-Fi",
                           poster: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn3.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcQovCe0H45fWwAtV31ajOdXRPTxSsMQgPIQ3lcZX_mAW0jXV3kH&psig=AOvVaw3XZPLnHcazsiYzJ9ri8D_B&ust=1759536945114000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCKDH_obghpADFQAAAAAdAAAAABAE",
                           synopsis: "A dream within a dream."))
    .preferredColorScheme(.dark)
}


