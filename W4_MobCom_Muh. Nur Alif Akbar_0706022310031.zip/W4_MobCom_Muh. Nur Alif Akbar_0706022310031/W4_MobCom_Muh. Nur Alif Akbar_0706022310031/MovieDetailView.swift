//
//  MovieDetailView.swift
//  W4_MobCom_Muh. Nur Alif Akbar_0706022310031
//
//  Created by Muh. Nur Alif Akbar on 03/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                // Poster
                if let url = URL(string: movie.poster), movie.poster.starts(with: "http") {
                    AsyncImage(url: url) { image in
                        image.resizable()
                             .scaledToFit()
                    } placeholder: {
                        ZStack {
                            Color.gray.opacity(0.3)
                            ProgressView()
                        }
                    }
                    .frame(height: 250)
                    .cornerRadius(15)
                    .shadow(color: .red.opacity(0.5), radius: 10, x: 0, y: 5)
                } else {
                    Image(movie.poster)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 250)
                        .cornerRadius(15)
                        .shadow(color: .red.opacity(0.5), radius: 10, x: 0, y: 5)
                }
                
                // Title & Genre
                Text(movie.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.red)
                
                Text("Genre: \(movie.genre)")
                    .font(.title3)
                    .foregroundColor(.white.opacity(0.8))
                
                // Synopsis
                Text("Synopsis")
                    .font(.headline)
                    .foregroundColor(.red)
                
                Text(movie.synopsis)
                    .font(.body)
                    .foregroundColor(.white)
                
                Spacer()
            }
            .padding()
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    NavigationStack {
        MovieDetailView(
            movie: Movie(title: "Inception",
                         genre: "Sci-Fi",
                         poster: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn3.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcQovCe0H45fWwAtV31ajOdXRPTxSsMQgPIQ3lcZX_mAW0jXV3kH&psig=AOvVaw3XZPLnHcazsiYzJ9ri8D_B&ust=1759536945114000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCKDH_obghpADFQAAAAAdAAAAABAE",
                         synopsis: "A thief who steals corporate secrets through dream-sharing technology is tasked with planting an idea into a target's subconscious.")
        )
    }
    .preferredColorScheme(.dark)
}
