//
//  ContentView.swift
//  W2_MobCom
//
//  Created by Muh. Nur Alif Akbar on 24/09/25.
//

import SwiftUI

struct Person {
    var name: String
    var phone: String
    var status: String
}

struct ContentView: View {
    // Data list
    let people: [Person] = [
        Person(name: "Alif", phone: "081234567890", status: "Mahasiswa"),
        Person(name: "Budi", phone: "089876543210", status: "Non-Mahasiswa"),
        Person(name: "Citra", phone: "082112345678", status: "Mahasiswa")
    ]
    
    // State untuk alert
    @State private var showAlert = false
    @State private var selectedName = ""

    var body: some View {
        VStack(spacing: 20) {
            ForEach(0..<people.count, id: \.self) { index in
                let person = people[index]
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Nama: \(person.name)")
                    Text("No Telp: \(person.phone)")
                    Text("Status: \(person.status)")
                    
                    HStack {
                        Spacer()
                        Button(action: {
                            selectedName = person.name
                            showAlert = true
                        }) {
                            Text("Welcome")
                                .font(.caption)
                                .padding(8)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .shadow(radius: 2)
            }
        }
        .padding()
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Selamat Datang"), message: Text("Selamat datang, \(selectedName)!"), dismissButton: .default(Text("OK")))
        }
    }
}

#Preview {
    ContentView()
}
