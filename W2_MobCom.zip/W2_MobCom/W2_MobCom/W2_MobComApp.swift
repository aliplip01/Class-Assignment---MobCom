//
//  W2_MobComApp.swift
//  W2_MobCom
//
//  Created by Muh. Nur Alif Akbar on 24/09/25.
//

import SwiftUI

@main
struct W2_MobComApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
