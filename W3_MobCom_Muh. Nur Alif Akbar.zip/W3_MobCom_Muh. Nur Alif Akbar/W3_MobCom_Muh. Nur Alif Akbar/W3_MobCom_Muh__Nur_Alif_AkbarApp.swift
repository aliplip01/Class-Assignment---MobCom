//
//  W3_MobCom_Muh__Nur_Alif_AkbarApp.swift
//  W3_MobCom_Muh. Nur Alif Akbar
//
//  Created by Muh. Nur Alif Akbar on 25/09/25.
//

import SwiftUI

@main
struct W3_MobCom_Muh__Nur_Alif_AkbarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
