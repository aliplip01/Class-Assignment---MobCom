//
//  ProfileView.swift
//  W3_MobCom_Muh. Nur Alif Akbar
//
//  Created by Muh. Nur Alif Akbar on 25/09/25.
//

import SwiftUI

struct ProfileView: View {
    @Binding var foodList: [String]
    @Binding var drinkList: [String]
    @Binding var animalList: [String]
    @Binding var countryList: [String]
    
    var body: some View {
        NavigationStack{
            VStack(spacing: 16) {
                HStack{
                    Image("pp_alip")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.gray, lineWidth: 2))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Muh. Nur Alif Akbar")
                            .font(.system(size: 20))
                            .fontWeight(.bold)
                        Text("Mahasiswa Sistem Informasi")
                            .font(.system(size: 18))
                        Text("20 years old")
                            .font(.system(size: 20))
                            .foregroundColor(.gray)
                    }
                }
                Divider()
                    .background(Color.black)
                    .padding(.bottom, 40)

                HStack(spacing: 16) {
                    NavigationLink(destination: FoodView(foodList: $foodList)) {
                        Text("🍕Food")
                            .frame(width: 150, height: 150)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(12)
                            
                    }

                    NavigationLink(destination: DrinkView(drinkList: $drinkList)) {
                        Text("🍷Drink")
                            .frame(width: 150, height: 150)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(12)
                    }
                }

                HStack(spacing: 16) {
                    NavigationLink(destination: AnimalView(animalList: $animalList)) {
                        Text("🐬Animal")
                            .frame(width: 150, height: 150)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(12)
                    }

                    NavigationLink(destination: CountryView(countryList: $countryList)) {
                        Text("🇮🇩Country")
                            .frame(width: 150, height: 150)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(12)
                    }
                }
            }
            .padding(24)
            Spacer()
        }
    }
}

#Preview {
    ContentView()
}
