//
//  UploadView.swift
//  W3_MobCom_Muh. Nur Alif Akbar
//
//  Created by Muh. Nur Alif Akbar on 25/09/25.
//

import SwiftUI

struct UploadContent: View {
    @State private var Food_String: String = ""
    @Binding var foodList: [String]
    
    @State private var Drink_String: String = ""
    @Binding var drinkList: [String]
    
    @State private var Animal_String: String = ""
    @Binding var animalList: [String]
    
    @State private var Country_String: String = ""
    @Binding var countryList: [String]
    
    var body: some View {
        VStack {
            VStack(alignment: .leading){
                Text("Favorite Food")
                HStack{
                    TextField("Fill your favorite food", text: $Food_String)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("+"){
                        if !Food_String.isEmpty{
                            foodList += [Food_String]
                            Food_String = ""
                        }
                    }
                    .buttonStyle(BorderedButtonStyle())
                }
                Text("Favorite Drink")
                HStack{
                    TextField("Fill your favorite drink", text: $Drink_String)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("+"){
                        if !Drink_String.isEmpty{
                            drinkList += [Drink_String]
                            Drink_String = ""
                        }
                    }
                    .buttonStyle(BorderedButtonStyle())
                }
                Text("Favorite Animal")
                HStack{
                    TextField("Fill your favorite animal", text: $Animal_String)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("+"){
                        if !Animal_String.isEmpty{
                            animalList += [Animal_String]
                            Animal_String = ""
                        }
                    }
                    .buttonStyle(BorderedButtonStyle())
                }
                Text("Favorite Country")
                HStack{
                    TextField("Fill your favorite country", text: $Country_String)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("+"){
                        if !Country_String.isEmpty{
                            countryList += [Country_String]
                            Country_String = ""
                        }
                    }
                    .buttonStyle(BorderedButtonStyle())
                }
            }
            .padding(24)
            Spacer()
        }
    }
}

#Preview {
    ContentView()
}
