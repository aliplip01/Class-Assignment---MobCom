//
//  ContentView.swift
//  W3_MobCom_Muh. Nur Alif Akbar
//
//  Created by Muh. Nur Alif Akbar on 25/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var foodList: [String] = []
    @State private var drinkList: [String] = []
    @State private var animalList: [String] = []
    @State private var countryList: [String] = []

    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house")
                }
            UploadContent(
                foodList: $foodList,
                drinkList: $drinkList,
                animalList: $animalList,
                countryList: $countryList
            )
                .tabItem {
                    Label("Upload", systemImage: "plus")
                }
            ProfileView(
                foodList: $foodList,
                drinkList: $drinkList,
                animalList: $animalList,
                countryList: $countryList
            )
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
        }
    }
}


struct HomeView: View {
    @State private var searchString: String = ""
    var body: some View {
        NavigationStack{
            VStack{
                HStack{
                    VStack(alignment: .leading){
                        Text("Good Morning,")
                            .font(.title2)
                            .padding(.bottom, -1)
                        Text("Nur Alif")
                            .font(.title)
                            .bold()
                    }
                    Spacer()
                    HStack{
                        Image("pp_alip")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 65, height: 65)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.gray, lineWidth: 2)
                            )
                    }
                }
                HStack{
                    TextField(" Search", text: $searchString) .textFieldStyle(RoundedBorderTextFieldStyle())
                }
                .padding(.bottom, 20)
                VStack{
                    HStack{
                        Text("Today's Goal")
                            .foregroundStyle(Color.white)
                            .font(.largeTitle)
                            .bold()
                    }
                    HStack{
                        VStack{
                            Image(systemName: "figure.run")
                                .font(.largeTitle)
                                .bold().foregroundColor(.white)
                            Text("4 Miles")
                                .font(.largeTitle)
                                .bold().foregroundColor(.white)
                            NavigationLink("@Running", destination: runn())
                                .foregroundStyle(Color.blue.opacity(30))
                        }
                        .padding()
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(10)
                        Spacer()
                        VStack{
                            Image(systemName: "figure.rower")
                                .font(.largeTitle)
                                .bold().foregroundColor(.white)
                                .padding(0.1)
                            Text("2 Miles")
                                .font(.largeTitle)
                                .bold().foregroundColor(.white)
                            NavigationLink("@Rower", destination: rowr())
                                .foregroundStyle(Color.blue)
                            
                        }
                        .padding()
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(10)
                    }
                    .padding()
                }
                .padding()
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.pink]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .cornerRadius(30)
                .shadow(radius: 10)
                .padding(.bottom, 20)
                VStack{
                    HStack{ //baris 1
                        VStack { //kotak 1
                            HStack {
                                Image(systemName: "cat.fill")
                                Spacer()
                            }
                            HStack {
                                Spacer()
                                Text("5")
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(14)
                        
                        VStack {
                            HStack { //kotak 2
                                Image(systemName: "service.dog.fill")
                                Spacer()
                            }
                            HStack {
                                Spacer()
                                Text("2")
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(14)
                    }
                    HStack{ // baris 2
                        VStack { //kotak 1
                            HStack {
                                Image(systemName: "ant.fill")
                                Spacer()
                            }

                            HStack {
                                Spacer()
                                Text("8.273.498.222")
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(14)
                        
                        VStack {
                            HStack { //kotak 2
                                Image(systemName: "fish.fill")
                                Spacer()
                            }
                            HStack {
                                Spacer()
                                Text("14")
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(14)
                    }
                }
                Spacer()
            }
            .padding()
            .background(Color.gray.opacity(0.2))
        }
    }
}

struct runn: View {
    var body: some View {
        Text("Hello, Test Running")
    }
}
struct rowr: View {
    var body: some View {
        Text("Hello, Test Rower")
    }
}
#Preview {
    ContentView()
}
