//
//  ListView.swift
//  W3_MobCom_Muh. Nur Alif Akbar
//
//  Created by Muh. Nur Alif Akbar on 25/09/25.
//

import SwiftUI

struct FoodView: View {
    @Binding var foodList: [String]
    var body: some View {
        VStack {
            Text("🍕 Favorite Foods")
                .font(.title)
                .padding()
            List(foodList, id: \.self) { item in
                Text(item)
            }
        }
    }
}

struct DrinkView: View {
    @Binding var drinkList: [String]
    var body: some View {
        VStack {
            Text("🍷 Favorite Drinks")
                .font(.title)
                .padding()
            List(drinkList, id: \.self) { item in
                Text(item)
            }
        }
    }
}

struct AnimalView: View {
    @Binding var animalList: [String]
    var body: some View {
        VStack {
            Text("🐬 Favorite Animals")
                .font(.title)
                .padding()
            List(animalList, id: \.self) { item in
                Text(item)
            }
        }
    }
}

struct CountryView: View {
    @Binding var countryList: [String]
    var body: some View {
        VStack {
            Text("🇮🇩 Favorite Countries")
                .font(.title)
                .padding()
            List(countryList, id: \.self) { item in
                Text(item)
            }
        }
    }
}
#Preview {
    ContentView()
}
